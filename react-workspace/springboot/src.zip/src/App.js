import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import Header from './components/Header';
import GetMenus from './components/GetMenus';

function App() {
  return (
    <div id="container">
      <Header/>
      <section id="content">
        <div id="menu-container" className='text-center'>
          <GetMenus />
        </div>
      </section>
    </div>
  );
}

export default App;
