import './App.css'

import { FetchGet ,FetchPost } from './12_Fetch';

import {AxiosGet , AxiosPost} from './13_axios';

import {Callback , PromiseThen} from './14_Callback';

function FetchApp(){
    return (
        //<FetchGet/>
        //<FetchPost/>
        //<AxiosGet/>
        //<AxiosPost/>
        //<Callback/>
        <PromiseThen/>
    )
}

export default FetchApp;