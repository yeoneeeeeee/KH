import TodoList from './TodoList';

function TodoApp(){
    return(
        <TodoList/>
    )
}
export default TodoApp;